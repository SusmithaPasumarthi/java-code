module EmployeeCollections {
}