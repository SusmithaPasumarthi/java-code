package com.java;	

	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.Map;
	import java.util.Collection;

	public class EmployeeCollection {

	    public static void main(String args[]) {
	        //       ***************Printing list of employees********************
	        ArrayList<String> employees = new ArrayList<>();
	        employees.add("Swetha");
	        employees.add("Keerthi");
	        employees.add("Sahithi");
	        employees.add("Prema");
	        employees.add("Niharika");
	        employees.add("Priyanka");
	        employees.add("Sindhu");
	        employees.add("Ashish");
	        employees.add("Deepak");
	        employees.add("Akash");
	        System.out.println("................. Employees list ................. \n ");
	        display(employees);


	        ArrayList<String> dept = new ArrayList<>();
	        dept.add("Developing Dept-4141");
	        dept.add("Testing Dept-2121");
	        dept.add("Production Dept-5151");
	        dept.add("Supporting Dept-3131");
	        System.out.println(".................  Departments list ................. \n ");
	        display(dept);



	        ArrayList<String> locations = new ArrayList<>();
	        locations.add("Chennai-11110");
	        locations.add("Banglore-11111");
	        locations.add("Pune-11112");
	        System.out.println(".................Locations list ................. \n ");
	        display(locations);



	        HashMap<String, String> map = new HashMap<>();
	        map.put("Swetha", "Developing Dept-4141");
	        map.put("Keerthi", "Testing Dept-2121");
	        map.put("Sahithi", "Production Dept-5151");
	        map.put("Prema", "Supporting Dept-3131");
	        map.put("Niharika", "Developing Dept-4141");
	        map.put("Priyanka", "Testing Dept-2121");
	        map.put("Sindhu", "Production Dept-5151");
	        map.put("Ashish", "Supporting Dept-3131");
	        map.put("Deepak", "Developing Dept-4141");
	        map.put("Aksha", "Testing Dept-2121");
	        System.out.println("................. Employees with their respective Departments ................. \n ");
	        for (Map.Entry<String, String> ed : map.entrySet()) {
	        System.out.println(ed.getKey() + "=" + ed.getValue());
	        }



	        System.out.println("................. Employees which are in Developing deparment code-4141 ................. \n ");
	        for (Map.Entry<String, String> e : map.entrySet())
	        if (e.getValue() == "Developing Dept-4141")
	        System.out.println(e.getKey());



	        HashMap<String, String> map1 = new HashMap<>();
	        map1.put("Developing Dept-4141", "Pune-11112");
	        map1.put("Testing Dept-2121", "Banglore-11111");
	        map1.put("Production Dept-5151", "Chennai-11110");
	        map1.put("Supporting Dept-3131", "Pune-11112");
	        System.out.println("................. Departments which are in Chennai Location ................. \n ");
	        for (Map.Entry<String, String> e : map1.entrySet())
	        if (e.getValue() == "Chennai-11110")
	        System.out.println(e.getKey());



	        HashMap<String, String> map2 = new HashMap<>();
	        map2.put("Krishna", "Pune-11112");
	        map2.put("Ravina", "Pune-11112");
	        map2.put("Padma", "Chennai-11110");
	        map2.put("Prem", "Pune-11112");
	        map2.put("Ruchita", "Banglore-11111");
	        map2.put("Priyanka", "Pune-11112");
	        map2.put("Dayana", "Banglore-11111");
	        map2.put("Ashish", "Chennai-11110");
	        map2.put("Ravi", "Pune-11112");
	        map2.put("Akashy", "Banglore-11111");
	        System.out.println("................. Employees for a given location Banglore .................\n ");
	        for (Map.Entry<String, String> e : map2.entrySet())
	        if (e.getValue() == "Banglore-11111")
	            System.out.println(e.getKey());
	    }

	    static void display(Collection col) {
	        for (Object ob : col) {
	            System.out.println(ob);
	        }
	    }
	}
