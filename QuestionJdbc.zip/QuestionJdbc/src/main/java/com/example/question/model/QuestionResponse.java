package com.example.question.model;



public class QuestionResponse {
    private QuestionDetails questionDetails;
   
    public QuestionResponse() {
        super();
    }
   
    public QuestionDetails getQuestionDetails() {
        return questionDetails;
    }
    public void setQuestionDetails(QuestionDetails questionDetails) {
        this.questionDetails = questionDetails;
    }
   


}