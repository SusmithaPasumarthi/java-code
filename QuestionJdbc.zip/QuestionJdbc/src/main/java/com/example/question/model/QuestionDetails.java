package com.example.question.model;


public class QuestionDetails {
    private QuestionDetailsList questionsList;
    
    public QuestionDetails() {
        super();
    }

    public QuestionDetailsList getQuestionsList() {
        return questionsList;
    }
    public void setQuestionsList(QuestionDetailsList questionsList) {
        this.questionsList = questionsList;
    }

	
}
    
