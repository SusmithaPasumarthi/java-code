package com.example.question.model;


 
public class TotalQuestions {

	
	
	private Questions questions;
	private PagingDetailsList pagingDetailsList;
	
	
	
	public Questions getQuestions() {
		return questions;
	}
	public void setQuestions(Questions question1) {
		this.questions = question1;
	}
	public PagingDetailsList getPagingDetailsList() {
		return pagingDetailsList;
	}
	public void setPagingDetailsList(PagingDetailsList pagingDetailsList) {
		this.pagingDetailsList = pagingDetailsList;
	}

	
	
}
