package com.example.question.model;



public class Question {
    private QuestionResponse questionResponse;



   public Question() {
        super();
    }

public QuestionResponse getQuestionResponse() {
	return questionResponse;
}
public void setQuestionResponse(QuestionResponse questionResponse) {
	this.questionResponse = questionResponse;
}



    
}