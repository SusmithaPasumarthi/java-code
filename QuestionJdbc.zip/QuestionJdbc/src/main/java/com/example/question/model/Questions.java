package com.example.question.model;



public class Questions {
	

	
	private QuestionsResponse questionResponse;
	         
	
 
	public QuestionsResponse getQuestionResponse() {
		return questionResponse;
	}

	public void setQuestionResponse(QuestionsResponse questionResponse) {
		this.questionResponse = questionResponse;
	}

	public Questions(QuestionsResponse questionResponse) {
		super();
		this.questionResponse = questionResponse;
	}

	public Questions() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	

	

    
}
