package com.example.question.validation;


public interface InputValidator {

	public boolean usernameValidator(String username);


}
     