package com.example.list;

import java.util.Comparator;
import java.util.Map;

public class ListMapComparator implements Comparator {

//	@Override
//	public int compare(Object o1, Object o2) {
//		// TODO Auto-generated method stub
//		return 0;
//	}
	
	public int compare(Object obj1, Object obj2) {
        Map<String, String> test1 = (Map<String, String>) obj1;
        Map<String, String> test2 = (Map<String, String>) obj2;
        return test1.get("name").compareTo(test2.get("name"));
   }

}
