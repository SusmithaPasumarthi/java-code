package com.example.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListEx {	
	
	public List<Map<String, String>> testMap() {

        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        Map<String, String> myMap1 = new HashMap<String, String>();
        myMap1.put("name", "Josh");
        Map<String, String> myMap2 = new HashMap<String, String>();
        myMap2.put("name", "Anna");
        Map<String, String> myMap3 = new HashMap<String, String>();
        myMap3.put("name", "Bernie");

        list.add(myMap1);
        list.add(myMap2);
        list.add(myMap3);

        return list;
   }

   public static void main(String[] args) {
        ListEx ms = new ListEx();
        List<Map<String, String>> testMap = ms.testMap();
        System.out.println("Before Sort: " + testMap);
        Collections.sort(testMap, new ListMapComparator());
        System.out.println("After Sort: " + testMap);
   }
}


