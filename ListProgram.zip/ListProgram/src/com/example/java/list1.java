package com.example.java;

import java.security.KeyStore.Entry;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class list1 {
	
	

	  public static void main(String[] args) {

	    // create a map and store elements to it
	    LinkedHashMap<String, String> capitals = new LinkedHashMap();
	    capitals.put("Nepal", "Kathmandu");
	    capitals.put("India", "New Delhi");
	    capitals.put("United States", "Washington");
	    capitals.put("England", "London");
	    capitals.put("Australia", "Canberra");

	    // call the sortMap() method to sort the map
	    Map<String, String> result = sortMap(capitals);

	    for (Map.Entry entry : result.entrySet()) {
	      System.out.print("Key: " + entry.getKey());
	      System.out.println(" Value: " + entry.getValue());
	    }
	  }

	  public static LinkedHashMap sortMap(LinkedHashMap map) {
	    List <Entry<String, String>> capitalList = new LinkedList<>(map.entrySet());

	    // call the sort() method of Collections
	    Collections.sort(capitalList, (l1, l2) -> l1.getValue().compareTo(l2.getValue()));

	    // create a new map
	    LinkedHashMap<String, String> result = new LinkedHashMap();

	    // get entry from list to the map
	    for (Map.Entry<String, String> entry : capitalList) {
	      result.put(entry.getKey(), entry.getValue());
	    }

	    return result;
	  }
	
//	
//	public static void main(String[] args) {
//
//	     Map<String, String> names = new HashMap<>();
//	    names.put("kethan", "k");
//	    names.put("Preethi", "A");
//	    names.put("Siri", "M");
//	    System.out.println("Map: " + names);
//
//	    // create a tree map from the map
//	    TreeMap<String, String> sortedNames = new TreeMap<>(names);
//	    System.out.println("Map with sorted Key" + sortedNames);
//
//	  }

//	 public static void main(String[] args) {
//
//		 Scanner input = null;
//		 String name;
//		 int age ;
//		 HashMap<String, Integer> hMap = new HashMap<String, Integer>();
//		 try {
//		 input=new Scanner(System.in);
//		 System.out.println("Build HashMap with Details:");
//		 while (input.hasNext()) {
//		 name = input.next();
//		 age = input.nextInt();
//		 hMap.put(name,age);
//		 }
//		 System.out.println("HashMap with Details:");
//		 hMap.forEach((Name,Age) -> System.out.println("Name: "+Name+
//		" Age:"+ Age));
//		 }
//		 catch (Exception e) {
//		 e.printStackTrace();
//		 } finally
//		 {
//		 if(input!=null)
//		 {input.close();}
//		 }
//
//		 }
}
