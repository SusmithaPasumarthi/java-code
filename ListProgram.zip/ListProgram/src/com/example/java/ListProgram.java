package com.example.java;

import java.util.HashMap;
//import java.util.Map;
import java.util.Scanner;

public class ListProgram {
	public static void main(String[] args) {



        Scanner input = null;
         String Fname;
         String Lname;
         HashMap<String, String> hMap = new HashMap<String, String>();
         try {
         input=new Scanner(System.in);
         System.out.println("Build HashMap with Details:");
         while (input.hasNext()) {
         Fname = input.next();
         Lname= input.next();
         hMap.put(Fname,Lname);
         }
         System.out.println("HashMap with Details:");
         hMap.forEach((FName,LName) -> System.out.println("FName: "+FName+
        " Lname:"+ LName));
         }
         catch (Exception e) {
         e.printStackTrace();
         } finally
         {
         if(input!=null)
         {input.close();}
         }



        }
}
