module WhileFunction {
}