module ReduceFunction {
}