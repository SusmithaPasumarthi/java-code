package com.api.java;

public class Pattern {
    public static void main(String args[]) {
        int rows[] = {1,2,3,4,5};        
        for (int i : rows)
        {
            for (int j : rows)
            {
                if(i>=j)
                     {
                    System.out.print("*");
                    }
                else
                    {
                    System.out.print("");
                    }
            }            
            System.out.println("");            
        }
    }
}
