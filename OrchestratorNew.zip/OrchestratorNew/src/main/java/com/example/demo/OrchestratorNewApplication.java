package com.example.demo;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.boot.context.properties.EnableConfigurationProperties;
//import com.example.question.configuration.MyConfiguration;

@SpringBootApplication
//@EnableConfigurationProperties(MyConfiguration.class)
//public class OrchestratorNewApplication implements CommandLineRunner{

	public class OrchestratorNewApplication{
//	private final MyConfiguration configuration;

//	  public OrchestratorNewApplication(MyConfiguration configuration) {
//	    this.configuration = configuration;
//	  }
	  public static void main(String[] args) {
		SpringApplication.run(OrchestratorNewApplication.class, args);
	}

//	  public void run(String... args) {
//
//	    Logger logger = LoggerFactory.getLogger(OrchestratorNewApplication.class);
//
//	    logger.info("----------------------------------------");
//	    logger.info("Configuration properties");
//	    logger.info("   example.username is {}", configuration.getUsername());
//	    logger.info("   example.password is {}", configuration.getPassword());
//	    logger.info("----------------------------------------");
//	  }
}
