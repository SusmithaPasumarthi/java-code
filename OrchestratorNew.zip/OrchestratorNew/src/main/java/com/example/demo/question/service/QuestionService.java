package com.example.demo.question.service;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.example.demo.question.model.Question;

@Service

public class QuestionService {

	RestTemplate resttemplate = new RestTemplate();


//	public Object getById(Question question) {
//		
//		HttpHeaders httpHeaders = new HttpHeaders();
//        httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//        HttpEntity<Question> entity = new HttpEntity<>(question,httpHeaders);
//        String url = "http://localhost:8080/api/v1/questions/{id}";
//        return resttemplate.exchange(url, HttpMethod.GET, entity, Object.class).getBody();
//                
//		
//	}
	public Object getQuestion(@PathVariable int id)  {   

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity <String> entity = new HttpEntity<>(httpHeaders);    
        String url = "http://localhost:8080/api/v1/questions/"+id;

        return resttemplate.exchange(url, HttpMethod.GET, entity, Object.class).getBody();
    
        
	}
    public Object save(Question question) 
    {

    	HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<Question> entity = new HttpEntity<>(question,httpHeaders);
        String url = "http://localhost:8080/api/v1/questions";
        return resttemplate.exchange(url, HttpMethod.POST, entity, Object.class).getBody();
                
    }
    
    public Object update(Question question) {
    	 
    	HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<Question> entity = new HttpEntity<>(question,httpHeaders);
        String url = "http://localhost:8080/api/v1/questions/"+question.getQuestionResponse().getQuestionDetails().getQuestionsList().getQuestionid();
        return resttemplate.exchange(url, HttpMethod.PUT, entity, Object.class).getBody();
         
    }
    
}
