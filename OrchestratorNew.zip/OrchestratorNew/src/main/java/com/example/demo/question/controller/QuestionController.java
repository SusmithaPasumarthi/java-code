package com.example.demo.question.controller;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.question.model.Question;
import com.example.demo.question.service.QuestionService;

@RestController
@RequestMapping("/questions")
public class QuestionController {
	
	RestTemplate resttemplate = new RestTemplate();

	
	@Autowired
	private QuestionService questionservice;
	
	
		@PostMapping("/questions")
		
		public ResponseEntity<Object> get(@RequestBody Question question )
		{
			try {
				//questionservice.getQuestion(question.getQuestionResponse().getQuestionDetails().getQuestionsList().getQuestionid()); 
					
				return new ResponseEntity<>(questionservice.update(question),HttpStatus.OK);
				
			} catch (Exception e) {
				
				
				return new ResponseEntity<>(questionservice.save(question), HttpStatus.OK);
			}


		}

    }
