package com.java;

public class EmployException extends Exception{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
EmployException(){}
EmployException(String error){
	super(error);
}
}
