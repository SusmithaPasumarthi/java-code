package com.java;

public enum Gender {
	MALE,FEMALE
}
