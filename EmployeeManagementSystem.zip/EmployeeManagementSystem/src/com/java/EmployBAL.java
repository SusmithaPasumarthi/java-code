package com.java;

import java.util.List;


public class EmployBAL {
	static StringBuilder sb = new StringBuilder();

	public String deleteEmployBal(int employId) {
		return new EmployDAO().deleteEmployDao(employId);
	}

	public Employ searchEmployBal(int employId) {
		return new EmployDAO().searchEmployDao(employId);
	}
	public String updateEmployBal(Employ employ) throws EmployException {
		EmployDAO dao = new EmployDAO();
		if (validateEmploy(employ)==true) {
			return dao.updateEmployDao(employ);
		} else {
			throw new EmployException(sb.toString());
		}
	}
	public List<Employ> showEmployBal() {
		return new EmployDAO().showEmployDao();
	}
	public String addEmployBal(Employ employ) throws EmployException {
		EmployDAO dao = new EmployDAO();
		if (validateEmploy(employ)==true) {
			return dao.addEmployDao(employ);
		} else {
			throw new EmployException(sb.toString());
		}
	}
	public boolean validateEmploy(Employ employ) {
		boolean isAdded=true;
		if (employ.getEmployId() <= 0) {
			isAdded=false;
			sb.append("Employ No Cannot be Negative or Zero\n");
		}
		
		if (employ.getName().length() <= 3) {
			isAdded=false;
			sb.append("Name cannot be less than 3 characters...\n");
		}
		
		if (employ.getCity().length() <= 3) {
			isAdded=false;
			sb.append("City Cannot be Less than 3 characters...\n");
		}
		
		if (employ.getPremium() >=10000) {
			isAdded=false;
			sb.append("Premium should be min 10000...\n");
		}
		return isAdded;
	}

}
