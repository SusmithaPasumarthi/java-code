package com.java;

import java.util.ArrayList;
import java.util.List;




public class EmployDAO {
static List<Employ> employList;
static {
	employList= new ArrayList<Employ>();
}
public String updateEmployDao(Employ employNew) {
	Employ old = searchEmployDao(employNew.getEmployId());
	if (old!=null) {
		old.setEmployId(employNew.getEmployId());
		old.setName(employNew.getName());
		old.setCity(employNew.getCity());
		old.setGender(employNew.getGender());
		old.setPremium(employNew.getPremium());
		return "Employ Record Updated...";
	}
	return "Employ Record Not Found...";
}


public String deleteEmployDao(int employId ) {
	Employ employ = searchEmployDao(employId);
	if (employ!=null) {
		employList.remove(employ);
		return "Employ Record Deleted...";
	} else {
		return "Employ Record Not Found...";
	}
}
public Employ searchEmployDao(int employId) {
	Employ employ = null;
	for (Employ s : employList) {
		if (s.getEmployId()==employId) {
			employ = s;
		}
	}
	return employ;
}

public String addEmployDao(Employ employ) {
	employList.add(employ);
	return "Employ Record Inserted Successfully...";
}
public List<Employ> showEmployDao() {
	return employList;
}
}
