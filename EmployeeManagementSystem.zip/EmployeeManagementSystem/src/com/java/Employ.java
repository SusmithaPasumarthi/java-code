package com.java;



public class Employ {
	

	private int employId;
	private String name;
	private String city;
	private Gender gender;
	private double premium;
	

	public int getEmployId() {
		return employId;
	}
	public void setEmployId(int employId) {
		this.employId = employId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public double getPremium() {
		return premium;
	}
	public void setPremium(double premium) {
		this.premium = premium;
	}
	public Employ(int employId, String name, String city, Gender gender, double premium) {
		super();
		this.employId = employId;
		this.name = name;
		this.city = city;
		this.gender = gender;
		this.premium = premium;
	}
	@Override
	public String toString() {
		return "Employ [employId=" + employId + ", name=" + name + ", city=" + city + ", gender=" + gender
				+ ", premium=" + premium + "]";
	}
	public Employ() {
		super();
		// TODO Auto-generated constructor stub
	}


}
