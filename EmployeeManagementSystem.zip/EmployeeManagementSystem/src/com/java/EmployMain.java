package com.java;

import java.util.List;
import java.util.Scanner;
public class EmployMain {
	static Scanner sc = new Scanner(System.in);
	
	public static void deleteEmploy() {
		System.out.println("Enter Employ No    ");
		int employId = sc.nextInt();
		EmployBAL bal = new EmployBAL();
		System.out.println(bal.deleteEmployBal(employId));
	}
	
	public static void searchEmploy() {
		System.out.println("Enter Employ No    ");
		int employId = sc.nextInt();
		EmployBAL bal = new EmployBAL();
		Employ employ = bal.searchEmployBal(employId);
		if (employ !=null) {
			System.out.println(employ);
		} else {
			System.out.println("*** Record Not Found ***");
		}
	}

	public static void updateEmploy() throws EmployException {
		Employ employ = new Employ();
		System.out.println("Enter EmployId  ");
		employ.setEmployId(sc.nextInt());
		System.out.println("Enter Employ Name  ");
		employ.setName(sc.next());
		System.out.println("Enter City   ");
		employ.setCity(sc.next());
		System.out.println("Enter Gender  ");
		String gen=sc.next();
		if (gen.equalsIgnoreCase("MALE")) {
			employ.setGender(Gender.MALE);
		}
		if (gen.equalsIgnoreCase("FEMALE")) {
			employ.setGender(Gender.FEMALE);
		}
		System.out.println("Enter Premium   ");
		employ.setPremium(sc.nextDouble());
		
		
		EmployBAL bal = new EmployBAL();
		System.out.println(bal.updateEmployBal(employ));
	}
	public static void addEmploy() throws EmployException {
		Employ employ = new Employ();
		System.out.println("Enter EmployId  ");
		employ.setEmployId(sc.nextInt());
		System.out.println("Enter Employ Name  ");
		employ.setName(sc.next());
		System.out.println("Enter City   ");
		employ.setCity(sc.next());
		System.out.println("Enter Gender  ");
		String gen=sc.next();
		if (gen.equalsIgnoreCase("MALE")) {
			employ.setGender(Gender.MALE);
		}
		if (gen.equalsIgnoreCase("FEMALE")) {
			employ.setGender(Gender.FEMALE);
		}
		System.out.println("Enter Premium   ");
		employ.setPremium(sc.nextDouble());
		
		EmployBAL bal = new EmployBAL();
		System.out.println(bal.addEmployBal(employ));
	}
	public static void showEmploy() {
		List<Employ> employList = new EmployDAO().showEmployDao();
		for (Employ employ: employList) {
			System.out.println(employ);
		}
	}
	public static void main(String[] args) {
		int choice=0;
		do {
			System.out.println("O P T I O N S");
			System.out.println("--------------");
			System.out.println("1. Add Employ ");
			System.out.println("2. Show Employ");
			System.out.println("3. Search Employ");
			System.out.println("4. Delete Employ");
			System.out.println("5. Update Employ");
			System.out.println("6. Exit");
			System.out.println("Enter Your Choice  ");
			choice=sc.nextInt();
			switch(choice) {
			case 1 :
				try {
					addEmploy();
				} catch (EmployException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2 :
				showEmploy();
				break;
			case 3 : 
				searchEmploy();
				break;
			case 4 :
				deleteEmploy();
				break;
			case 5 : 
				try {
					updateEmploy();
				} catch (EmployException e) {
					e.printStackTrace();
				}
				break;
			case 6 : 
				return;
			}
		}while(choice!=6);
	}
}