package com.java.employee;


public class Address {

	
	

    String City;
    String State;
    String Landmark;
    long Pincode;
    String Country;


    public Address(String City, String State, String Landmark, long Pincode, String Country)
    {
        this.City = City;
        this.State = State;
        this.Landmark = Landmark;
        this.Pincode = Pincode;
        this.Country = Country;
    
}
}



