package com.java.employee;

public class SalaryDetails {

	
	
	 long basicPay;
	    long variablePay;
	    long travelingAllowance;
	    long dearnessAllowance;
	    long totalSalary;

	    public SalaryDetails(long basicPay, long variablePay, long TravelingAllowance, long DearnessAllowance, long TotalSalary)
	    {
	        this.basicPay = basicPay;
	        this.variablePay = variablePay;
	        this.travelingAllowance = TravelingAllowance;
	        this.dearnessAllowance = DearnessAllowance;
	        this.totalSalary = TotalSalary;
	    }
}
