package com.java.employee;

public class Employee {

    int id;
    String name;
    String emailId;
    String role;
    Address address;
    SalaryDetails salarydetails;
    Skills skills;
    public Employee(int id, String name,String role,String emailiD, Address address, SalaryDetails salarydetails,
          Skills skills) {

      this.id = id;
      this.name = name;
      this.emailId = emailiD;
      this.role = role;
      this.address = address;
      this.salarydetails = salarydetails;
      this.skills = skills;
  }

  
  void display() {
      System.out.println("\t" +id + "\t" + name + "\t" + emailId + "\t" + role );
      System.out.println("\t" +address.City + "\t" + address.State + "\t" + address.Landmark + "\t" + address.Pincode + "\t"
              + address.Country);
      System.out
              .println("\t" + salarydetails.basicPay + "\t" + salarydetails.variablePay + "\t" + salarydetails.travelingAllowance
                      + "\t" + salarydetails.dearnessAllowance + "\t" + salarydetails.totalSalary);
      System.out.println("\t" + skills.technology + "\t" + skills.experience + "\t" + skills.ratingOfYourSkill+ "\n");
  }

  public static void main(String[] args) {

      Address address1 = new Address("Hyderabad","Telangana","Cyber city",524315,"India");
      Address address2 = new Address("Vijayawada","Andhra Pradesh","Kailasagiri",524300,"India");

      SalaryDetails salarydetails1 = new SalaryDetails(30000,  1800, 2000, 1500, 35300);
      SalaryDetails salarydetails2 = new SalaryDetails(20000, 1600, 1600, 1200, 24400);

      Skills skills1 = new Skills("Java",2,4);
      Skills skills2 = new Skills("Frontend",3,4.5);


      Employee e1 = new Employee(111,"Keerthi","keerthi@123","Developer ",address1,salarydetails1,skills1  );
      Employee e2 = new Employee(112,"Nikhil","nikhil@12345","Developer  ",address2,salarydetails2,skills2);


      e1.display();

      e2.display();
  }

}
