package com.java.employee;

public class Skills {

	
    String technology;
    int experience;
    double ratingOfYourSkill;


    public Skills(String Technology, int Experience, double ratingOFYourSkill)
    {
        this.technology = Technology;
        this.experience = Experience;
        this.ratingOfYourSkill = ratingOFYourSkill;
    }
}
