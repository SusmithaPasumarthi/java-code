package com.java;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;


public class Collections {

	public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        do {
            System.out.println("----------Java Collections------");
            System.out.println("1.ArrayList. \n"+
                               "2.Priority Queue\n"+
                               "3.HashSet\n"+
                               "4.TreeSet\n"+
                               "5.Map\n"+
                               "6.HashMap\n"+
                               "7.LinkedHashSet\n"+
                               "8.Exist \n"
                              
                             
                    );
            System.out.println("Enter Your Choice :-  ");
            int ch =sc.nextInt();
            switch(ch)
            {
            case 1:System.out.println("ArrayList");
                    arrayList();
                     break;
            case 2:System.out.println("Priority Queue");
                   priorityQueue();
                   break;
            case 3:System.out.println("HashSet");
                   hashSet();
                   break;
            case 4:System.out.println("TreeSet");
                   treeSet();
                   break;
            case 5:System.out.println("Map");
                   map();
                   break;
            case 6:System.out.println("HashMap");
                   hashMap();
                   break;
            case 7:System.out.println("LinkedHashSet");
            linkedHashSet();
            break;
                   
            case 8:System.out.println("\nYou are Successfully Exited");
                   System.exit(0);
                   break;
            default : System.out.println("\nEnter a Correct Choice");
                      break;
            }
        }while(true);

    }
    //////////ArrayList///////////////////
    static void arrayList() {
        ArrayList<String> Flowers = new ArrayList<>();
        Flowers.add("Rose");
        Flowers.add("Jasmine");
        Flowers.add("SunFlower");
        Flowers.add("Tulip");
        Iterator itr = Flowers.iterator();
        while(itr.hasNext()) {
            System.out.println(itr.next());
        }
    }
    ////////PriorityQueue//////////////
    static void priorityQueue() {
        PriorityQueue<String> queue = new PriorityQueue<String>();
        queue.add("Keerthi setty");
        queue.add("Ramya Dev");
        queue.add("Nikhil Gadham");
        queue.add("Suraj keythi");
        System.out.println("head :"+queue.element());
        System.out.println("head :"+queue.peek());
        System.out.println("------iterating the queue elements------");
        Iterator itr =queue.iterator();
        while(itr.hasNext()) {
            System.out.println(itr.next());    
        }

    }
    //////////HashSet////////////////
    static void hashSet() {
        HashSet<String> set = new HashSet<String>();
        set.add("Keerthi");
        set.add("Ramya");
        set.add("Deepak");
        set.add("Ramya");
        Iterator<String> itr = set.iterator();
        while(itr.hasNext()) {
            System.out.println(itr.next());
        }
    }

    /////////TreeSet///////////////
    static void treeSet() {
        TreeSet<String> set = new TreeSet<String>();
        set.add("Keerthi");
        set.add("Ramya");
        set.add("Nikhil");
        set.add("Vishnu");
        Iterator<String> itr = set.iterator();
        while(itr.hasNext()) {
            System.out.println(itr.next());
        }
    }
    //////////////Map//////////////
    static void map() {
        Map<Integer,String> Fruits = new HashMap<Integer,String> ();
        Fruits.put(1, "Apple");
        Fruits.put(2,"Mango");
        Fruits.put(3,"Grapes");
        for(Map.Entry m :Fruits.entrySet()) {
            System.out.println(m.getKey() + " " + m.getValue());
        }
    }
    //           HashMap              //
    static void hashMap() {
        HashMap<Integer, String> hashMap = new HashMap<Integer, String>();
        hashMap.put(1,"Keerthi");
        hashMap.put(2,"Prema");
        hashMap.put(3,"Ramya");
        System.out.println("----Iterating HashMap----");
        for(Map.Entry m : hashMap.entrySet()) {
            System.out.println(m.getKey() + " " +m.getValue());
        }
	  }
//				 LinkedHashSet              //
    
    static void linkedHashSet() {
        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
        linkedHashSet.add("Keerthy");
        linkedHashSet.add("Vineela");
        linkedHashSet.add("Amrutha");
        linkedHashSet.add("Karthik");
        linkedHashSet.add("Sridhar");
        Iterator<String> itr = linkedHashSet.iterator();
        while (itr.hasNext()) {
            System.out.println(itr.next());
        }
}
}
