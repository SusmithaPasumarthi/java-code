package com.Java.LinkedList;

import java.util.Iterator;

public class LinkedListExample {

	
	 public static void main(String args[]){  
		  
		  LinkedListExample<String> al=new LinkedListExample<String>();  
		  al.add("Ravi");  
		  al.add("Vijay");  
		  al.add("Ravi");  
		  al.add("Ajay");  
		  
		  Iterator<String> itr=al.iterator();  
		  while(itr.hasNext()){  
		   System.out.println(itr.next());  
		  }  
		 }
}
