module InterfaceExercise {
}