package com.exercise;

public class CharSequnceDemo implements CharSequence 
{
	
	
		private String s;
			
			public CharSequnceDemo(String text) {
				super();
				this.s = s;
		    }
			
			private int fromEnd(int i) {
		        return s.length() - 1 - i;
			}
			@Override
		    public int length() {
		        return this.s.length();
		    }

		    @Override
		    public char charAt(int index) {
		    	 if ((index < 0) || (index >= s.length())) {
		             throw new StringIndexOutOfBoundsException(index);
		         }
		         return s.charAt(fromEnd(index));
		    }

		    @Override
		    public CharSequence subSequence(int start, int end) {
		    	 if (start < 0) {
		             throw new StringIndexOutOfBoundsException(start);
		         }
		         if (end > s.length()) {
		             throw new StringIndexOutOfBoundsException(end);
		         }
		         if (start > end) {
		             throw new StringIndexOutOfBoundsException(start - end);
		         }
		         
		         return this.s.subSequence(start, end);
		    }    
		    
		    @Override
		    public String toString() {
		        StringBuilder text = new StringBuilder(this.s);
		        return text.reverse().toString();
		    }
		    
			public static void main(String args[]) {
				CharSequnceDemo c= new CharSequnceDemo("Srija Karumuri");	
		    	  for (int i = 0; i < c.length(); i++) {
		              System.out.print(c.charAt(i));
		          }         
		          System.out.println("");
		          System.out.println(c.subSequence(3, 2));
		          System.out.println(c);
			}
	
}
