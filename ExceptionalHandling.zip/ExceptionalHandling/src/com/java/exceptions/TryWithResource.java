package com.java.exceptions;
import java.io.FileOutputStream;
	public class TryWithResource {    
		
	   public static void main(String args[]){ 
		   
	    try{   
	    	
	        FileOutputStream fileOutputStream =new FileOutputStream("C:/Users/pasumarthi.susmitha/Downloads/Text.txt");  
	        String msg = "Welcome to Exception Handling";  
	      //converting string into byte array 
	        byte byteArray[] = msg.getBytes();      
	        fileOutputStream.write(byteArray);  
	        System.out.println("Message written to file successfuly!");      
	    }
	    catch(Exception exception){  
	           System.out.println(exception);  
	    }  
	   }
}
