package com.java.exceptions;


public class MultipleCatchExample {
    public static void main(String[] args) {        
    	try{
            int array[]= {4,5,10,30,16};
        
            System.out.println("5th element of given array divided by Zero   "+(array[4]/4));
            
          
        }    
           catch(ArithmeticException e)  
               {  
                System.out.println("Arithmetic Exception occurs");  
               }    
           catch(ArrayIndexOutOfBoundsException e)  
               {  
                System.out.println("ArrayIndexOutOfBounds Exception occurs");  
               }    
             
}    
}
