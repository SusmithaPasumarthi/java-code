package com.java.exceptions;

public class CustomException
{
    static void validate(int age) {
     if(age<18)
     {
         throw new ArithmeticException("You are not eligible for vote");
     }
     else
     {
         System.out.println("You are eligible for vote");
     }
}
public static void main(String args[])
{
    validate(18);
    System.out.println("Program Successfully Completed");
    }
}
