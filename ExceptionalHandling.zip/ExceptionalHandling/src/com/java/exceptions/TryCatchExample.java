package com.java.exceptions;

public class TryCatchExample {
	public static void main(String[] args) {
	        try {
	          int divideByZero = 5 / 1;
	          System.out.println("Rest of code in try block");
	        }
	        
	        catch (ArithmeticException e) {
	          System.out.println("ArithmeticException => " + e.getMessage());
	        }
	   
	        }
}