package com.java;
import java.util.Scanner;

public class RiceBag {
	public int countSmallBags(int goal,int bigBag, int smallBag) {
		if((bigBag*5>=goal)&& (smallBag>=goal%5)) {
			
			return goal%5;
			
		}
		else if(smallBag>=goal-bigBag*5)
			return goal-bigBag*5;
		return -1;		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		char ans= 'y';
		while(ans=='y') {
			System.out.println("enter goal:" );
			int goal=sc.nextInt();
			System.out.println("ente number of big bags: ");
			int bigBag=  sc.nextInt();
			System.out.println("ente number of small bags: ");
			int smallBag=  sc.nextInt();
			RiceBag a =new RiceBag();
			System.out.println("Total small Bags are used :" +a.countSmallBags(goal,bigBag, smallBag));
			System.out.println("you want check for other goal? if yes press 'y' or else press 'n'");
			char an=sc.next().charAt(0);
			ans=an;
		}
		if(ans=='n')
	System.out.println("Thank You");
}
}