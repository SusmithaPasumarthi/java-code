package com.java;

public class Node {

	public Node left;
	public Node right;
	public int key;

}
