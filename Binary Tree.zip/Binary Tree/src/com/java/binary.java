package com.java;
import java.util.Scanner;
public class binary {
	public static int findADepth(Node node) {
		int depth = 0;
		return depth;
		} 
	private static Boolean isPerfectTree(Node node, int depth, int treeDepth) {
		if ((node.left == null) && (node.right == null)) {
			return true;
			}
		if ((node.left != null && node.right != null)) {
			return isPerfectTree(node.left, 1 + depth, treeDepth) && isPerfectTree(node.right, 1 + depth, treeDepth);
			}
		return false;
		} 
	public static boolean isPerfect(Node node) {int depth = findADepth(node);
	return isPerfectTree(node, depth, 0);
	} 
	public static Node newNode(int k) {
		Node node = new Node();
		node.key = k;
		node.right = null;
		node.left = null;
		return node;
		}
	public static void main(String args[]) {
		Node node = null;
		node = newNode(10);
		node.left = newNode(10);
		node.right = newNode(20);
		if (isPerfect(node) == true)
			System.out.println("Yes it is a Prefect Binart Tree");
		else
			System.out.println("No it is not a Prefect Binart Tree"); Node node1 = null;
			node1 = newNode(40);
			node1.left = newNode(10);
			node1.right = newNode(20);
			node1.left.right = newNode(30);
			if (isPerfect(node1) == true)
				System.out.println("Yes it is a Prefect Binart Tree");
			else
				System.out.println("No it is not a Prefect Binart Tree");
			}
	}
